import fs from 'fs';
import path from 'path';

class ImageMetadataService {
  constructor(metadataDir = './image-metadata') {
    this.metadataDir = metadataDir;
    // 确保元数据目录存在
    if (!fs.existsSync(this.metadataDir)) {
      fs.mkdirSync(this.metadataDir, { recursive: true });
    }
  }

  // 获取图片元数据文件路径
  getMetadataFilePath(filename) {
    const metadataFilename = `${path.parse(filename).name}.json`;
    return path.join(this.metadataDir, metadataFilename);
  }

  // 保存图片元数据
  saveMetadata(filename, metadata) {
    try {
      const filePath = this.getMetadataFilePath(filename);
      const fullMetadata = {
        filename,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...metadata
      };
      fs.writeFileSync(filePath, JSON.stringify(fullMetadata, null, 2));
      return { success: true, metadata: fullMetadata };
    } catch (error) {
      console.error('保存元数据失败:', error);
      return { success: false, error: error.message };
    }
  }

  // 获取图片元数据
  getMetadata(filename) {
    try {
      const filePath = this.getMetadataFilePath(filename);
      if (fs.existsSync(filePath)) {
        const metadata = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        return { success: true, metadata };
      }
      return { success: false, error: '元数据不存在' };
    } catch (error) {
      console.error('获取元数据失败:', error);
      return { success: false, error: error.message };
    }
  }

  // 更新图片元数据
  updateMetadata(filename, updateData) {
    try {
      const filePath = this.getMetadataFilePath(filename);
      if (fs.existsSync(filePath)) {
        const existingMetadata = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        const updatedMetadata = {
          ...existingMetadata,
          ...updateData,
          updatedAt: new Date().toISOString()
        };
        fs.writeFileSync(filePath, JSON.stringify(updatedMetadata, null, 2));
        return { success: true, metadata: updatedMetadata };
      }
      return { success: false, error: '元数据不存在' };
    } catch (error) {
      console.error('更新元数据失败:', error);
      return { success: false, error: error.message };
    }
  }

  // 删除图片元数据
  deleteMetadata(filename) {
    try {
      const filePath = this.getMetadataFilePath(filename);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        return { success: true };
      }
      return { success: false, error: '元数据不存在' };
    } catch (error) {
      console.error('删除元数据失败:', error);
      return { success: false, error: error.message };
    }
  }

  // 批量获取图片元数据
  batchGetMetadata(filenames) {
    return filenames.map(filename => {
      const result = this.getMetadata(filename);
      return {
        filename,
        ...result
      };
    });
  }
}

export default ImageMetadataService;