/**
 * NanoFlow Studio SSH Upload Server
 * 作者: 邓昭涛
 * 邮箱: 3277299389@qq.com
 * 版权所有 © 2026
 * 
 * 注意: 本代码为开源项目，欢迎使用和修改，但请保留作者信息
 * 如需商业使用，请联系作者获得授权
 */

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const sharp = require('sharp');
const { Client } = require('ssh2');
const { exec } = require('child_process');
const ssh2 = require('ssh2');
const SftpClient = require('ssh2-sftp-client');

// 使用动态导入加载ES模块
let ImageMetadataService;
let metadataService;

(async () => {
  try {
    const { default: ImageMetadataServiceModule } = await import('./imageMetadataService.js');
    ImageMetadataService = ImageMetadataServiceModule;
    metadataService = new ImageMetadataService();
    console.log('元数据服务初始化成功');
  } catch (error) {
    console.error('初始化元数据服务失败:', error);
    process.exit(1);
  }
})();

// 移除全局SFTP客户端实例，改为每次上传创建新实例

const app = express();
const upload = multer({ dest: 'uploads/' });

// 添加JSON解析中间件，用于处理base64上传请求
app.use(express.json({ limit: '10mb' }));

// 添加静态文件服务，用于提供UI界面
app.use(express.static('public'));

// 配置上传目录的静态访问，确保上传的文件能通过/images/路径访问
app.use('/images', express.static('./uploads'));
// 保留本地文件，不删除，确保本地URL能访问
// 注意：在生产环境中应该删除本地文件，这里为了开发调试保留

// 配置
const SERVER_CONFIG = {
  HOST: process.env.SSH_HOST || 'localhost',
  USERNAME: process.env.SSH_USERNAME || 'user',
  PASSWORD: process.env.SSH_PASSWORD || '',
  PRIVATE_KEY_PATH: process.env.SSH_PRIVATE_KEY_PATH || '',
  REMOTE_PATH: process.env.SSH_REMOTE_PATH || '/home/user/images',
  HTTP_PORT: parseInt(process.env.HTTP_PORT) || 8083,
  LOCAL_UPLOAD_DIR: './uploads',
  // 图片压缩配置
  IMAGE_COMPRESSION: {
    QUALITY: 85,
    MAX_WIDTH: 2000,
    MAX_HEIGHT: 2000,
  },
};

// 确保上传目录存在
if (!fs.existsSync(SERVER_CONFIG.LOCAL_UPLOAD_DIR)) {
  fs.mkdirSync(SERVER_CONFIG.LOCAL_UPLOAD_DIR, { recursive: true });
}

// 图片压缩函数
async function compressImage(filePath, quality = 85, maxWidth = 2000, maxHeight = 2000) {
  try {
    console.log(`开始压缩图片: ${filePath}`);
    
    const image = sharp(filePath);
    const metadata = await image.metadata();
    
    // 计算缩放比例
    let width = metadata.width;
    let height = metadata.height;
    
    if (width > maxWidth || height > maxHeight) {
      const ratio = Math.min(maxWidth / width, maxHeight / height);
      width = Math.round(width * ratio);
      height = Math.round(height * ratio);
    }
    
    // 使用临时文件进行压缩
    const tempFilePath = `${filePath}.tmp`;
    await image
      .resize(width, height, { fit: 'inside' })
      .jpeg({ quality })
      .toFile(tempFilePath);
    
    // 替换原文件
    fs.unlinkSync(filePath);
    fs.renameSync(tempFilePath, filePath);
    
    console.log(`图片压缩完成: ${filePath} (${width}x${height})`);
    return true;
  } catch (error) {
    console.error(`图片压缩失败: ${filePath}`, error);
    return false;
  }
}

// 上传文件到云服务器
async function uploadToCloudServer(localFilePath, remoteFileName) {
  // 检查是否配置了必要的SSH信息
  if (!SERVER_CONFIG.HOST || !SERVER_CONFIG.USERNAME || (!SERVER_CONFIG.PASSWORD && !SERVER_CONFIG.PRIVATE_KEY_PATH)) {
    console.log(`=== SSH配置不完整，跳过云服务器上传 ===`);
    console.log(`请设置环境变量: SSH_HOST, SSH_USERNAME, 以及SSH_PASSWORD或SSH_PRIVATE_KEY_PATH`);
    throw new Error('SSH配置不完整，无法上传到云服务器');
  }
  
  console.log(`=== 开始SFTP上传文件 ===`);
  console.log(`本地文件路径: ${localFilePath}`);
  console.log(`远程文件名: ${remoteFileName}`);
  console.log(`远程服务器: ${SERVER_CONFIG.HOST}`);
  console.log(`远程路径: ${SERVER_CONFIG.REMOTE_PATH}`);
  
  // 每次上传创建新的SFTP客户端实例
  const sftpClient = new SftpClient();
  
  try {
    // 构建连接配置
    const connectConfig = {
      host: SERVER_CONFIG.HOST,
      port: 22,
      username: SERVER_CONFIG.USERNAME,
      strictHostKeyChecking: false
    };
    
    // 添加认证信息
    if (SERVER_CONFIG.PRIVATE_KEY_PATH) {
      try {
        connectConfig.privateKey = fs.readFileSync(SERVER_CONFIG.PRIVATE_KEY_PATH);
      } catch (keyError) {
        console.error(`读取私钥文件失败: ${keyError.message}`);
      }
    }
    
    if (SERVER_CONFIG.PASSWORD) {
      connectConfig.password = SERVER_CONFIG.PASSWORD;
    }
    
    // 连接到SFTP服务器
    await sftpClient.connect(connectConfig);
    
    console.log(`SFTP连接成功`);
    
    // 确保远程目录存在
    const remoteDir = SERVER_CONFIG.REMOTE_PATH;
    const dirExists = await sftpClient.exists(remoteDir);
    
    if (!dirExists) {
      console.log(`远程目录不存在，创建目录: ${remoteDir}`);
      await sftpClient.mkdir(remoteDir, true);
      console.log(`目录创建成功`);
    }
    
    // 上传文件
    const remoteFilePath = `${SERVER_CONFIG.REMOTE_PATH}/${remoteFileName}`;
    await sftpClient.put(localFilePath, remoteFilePath);
    
    console.log(`文件上传成功: ${remoteFilePath}`);
    
    // 关闭SFTP连接
    await sftpClient.end();
    
    console.log(`SFTP连接已关闭`);
    return true;
  } catch (error) {
    console.error(`SFTP上传失败: ${error.message}`);
    console.error(`完整错误:`, error);
    
    // 确保关闭连接
    try {
      await sftpClient.end();
    } catch (closeError) {
      console.error(`关闭SFTP连接失败: ${closeError.message}`);
    }
    
    throw error;
  }
}

// CORS中间件
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

// 使用更兼容的方式处理OPTIONS请求
app.use((req, res, next) => {
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// 健康检查端点
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    message: '服务器运行正常',
    timestamp: new Date().toISOString(),
    config: {
      host: SERVER_CONFIG.HOST,
      port: SERVER_CONFIG.HTTP_PORT,
      remotePath: SERVER_CONFIG.REMOTE_PATH
    }
  });
});

// 上传接口
app.post('/upload', async (req, res) => {
  try {
    console.log('=== 收到上传请求 ===');
    console.log('Content-Type:', req.headers['content-type']);
    
    let file, fileName, fileType, fileSize;
    let isBase64Upload = false;
    let metadata = {};
    
    // 检查是否为base64上传（JSON格式）
    if (req.headers['content-type']?.includes('application/json')) {
      isBase64Upload = true;
      const body = req.body;
      
      if (!body.imageData) {
        return res.status(400).json({
          success: false,
          error: '未收到base64数据'
        });
      }
      
      // 解析base64数据
      const base64Data = body.imageData.replace(/^data:[^;]+;base64,/, '');
      const buffer = Buffer.from(base64Data, 'base64');
      
      fileName = body.fileName || `upload-${Date.now()}.png`;
      fileType = body.fileType || 'image/png';
      fileSize = buffer.length;
      
      // 提取元数据
      metadata = {
        prompt: body.prompt || '',
        description: body.description || '',
        tags: body.tags || [],
        model: body.model || '',
        originalFileName: fileName
      };
      
      // 创建临时文件
      const tempFileName = `temp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const tempFilePath = path.join(require('os').tmpdir(), tempFileName);
      fs.writeFileSync(tempFilePath, buffer);
      
      // 创建文件对象
      file = {
        originalname: fileName,
        filename: tempFileName,
        path: tempFilePath,
        mimetype: fileType,
        size: fileSize
      };
      
      console.log('=== 处理base64上传 ===');
    } else {
      // 文件上传（multipart/form-data格式）
      // 使用multer中间件处理
      const uploadSingle = upload.single('file');
      
      uploadSingle(req, res, (err) => {
        if (err) {
          console.error('Multer错误:', err);
          return res.status(400).json({
            success: false,
            error: '文件上传失败: ' + err.message
          });
        }
        
        if (!req.file) {
          return res.status(400).json({
            success: false,
            error: '未收到文件'
          });
        }
        
        // 继续处理文件上传
        processFileUpload(req.file, req.body, res);
      });
      
      return; // 提前返回，让回调继续处理
    }
    
    // 处理base64上传
    await processFileUpload(file, metadata, res, isBase64Upload);
  } catch (error) {
    console.error('=== 处理上传请求失败 ===');
    console.error('错误:', error.message);
    
    res.json({
      success: false,
      error: error.message || '上传失败',
    });
  }
});

// 处理文件上传的辅助函数
async function processFileUpload(file, metadataOrBody, res, isBase64Upload = false) {
  try {
    let fileName, fileType, fileSize;
    let metadata = {};
    
    if (isBase64Upload) {
      // base64上传，metadata已经是对象
      fileName = file.originalname;
      fileType = file.mimetype;
      fileSize = file.size;
      metadata = metadataOrBody;
      console.log('=== 处理base64上传 ===');
    } else {
      // 文件上传，metadataOrBody是req.body
      file = file;
      fileName = file.originalname;
      fileType = file.mimetype;
      fileSize = file.size;
      
      // 提取元数据（从表单字段）
      metadata = {
        prompt: metadataOrBody.prompt || '',
        description: metadataOrBody.description || '',
        tags: metadataOrBody.tags ? JSON.parse(metadataOrBody.tags) : [],
        model: metadataOrBody.model || '',
        originalFileName: fileName
      };
      
      console.log('=== 处理文件上传 ===');
    }
    
    // 生成唯一文件名，如果有提示词，使用提示词的前20个字符作为文件名的一部分
    let uniqueFileName;
    if (metadata.prompt) {
      const promptPrefix = metadata.prompt.substring(0, 20).replace(/[^a-zA-Z0-9]/g, '-');
      uniqueFileName = `${Date.now()}-${promptPrefix}-${Math.random().toString(36).substr(2, 6)}${path.extname(file.originalname)}`;
    } else {
      uniqueFileName = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}${path.extname(file.originalname)}`;
    }
    
    // 确保本地上传目录存在
    if (!fs.existsSync(SERVER_CONFIG.LOCAL_UPLOAD_DIR)) {
      fs.mkdirSync(SERVER_CONFIG.LOCAL_UPLOAD_DIR, { recursive: true });
    }
    
    // 移动文件到本地上传目录
    const targetFilePath = path.join(SERVER_CONFIG.LOCAL_UPLOAD_DIR, uniqueFileName);
    if (isBase64Upload) {
      // 对于base64上传，直接复制文件
      fs.copyFileSync(file.path, targetFilePath);
      // 清理临时文件
      fs.unlinkSync(file.path);
    } else {
      // 文件移动逻辑
      fs.renameSync(file.path, targetFilePath);
    }
    
    console.log('=== 文件保存到本地 ===');
    
    // 图片压缩
    if (file.mimetype.startsWith('image/')) {
      console.log('=== 开始图片压缩 ===');
      await compressImage(
        targetFilePath,
        SERVER_CONFIG.IMAGE_COMPRESSION.QUALITY,
        SERVER_CONFIG.IMAGE_COMPRESSION.MAX_WIDTH,
        SERVER_CONFIG.IMAGE_COMPRESSION.MAX_HEIGHT
      );
      console.log('=== 图片压缩成功 ===');
    }
    
    // 构建可访问的URL
    const localUrl = `http://localhost:${SERVER_CONFIG.HTTP_PORT}/images/${uniqueFileName}`;
    const remoteUrl = `http://${SERVER_CONFIG.HOST}:8083/images/${uniqueFileName}`;
    const fullRemoteUrl = `http://${SERVER_CONFIG.HOST}:8083/images/${uniqueFileName}`;
    
    // 更新元数据，添加URL信息
    metadata = {
      ...metadata,
      localUrl,
      remoteUrl,
      fullRemoteUrl,
      fileSize: fs.statSync(targetFilePath).size,
      fileType: file.mimetype
    };
    
    // 保存元数据
    metadataService.saveMetadata(uniqueFileName, metadata);
    
    // 尝试上传到云服务器
    try {
      console.log('=== 开始上传到云服务器 ===');
      await uploadToCloudServer(targetFilePath, uniqueFileName);
      console.log('=== 上传到云服务器成功 ===');
      
      console.log('=== 上传完成 ===');
      console.log('文件名:', uniqueFileName);
      console.log('原始文件名:', fileName);
      console.log('本地URL:', localUrl);
      console.log('远程URL:', remoteUrl);
      
      res.json({
        success: true,
        url: remoteUrl,
        localUrl,
        fullRemoteUrl,
        name: uniqueFileName,
        originalName: fileName,
        size: fileSize,
        type: fileType,
        metadata
      });
    } catch (uploadError) {
      // SFTP上传失败，进入测试模式
      console.error('=== 上传到云服务器失败 ===');
      console.error('错误:', uploadError.message);
      
      console.log('=== 进入测试模式 ===');
      console.log('本地文件路径:', targetFilePath);
      
      res.json({
        success: true,
        url: localUrl,
        localUrl,
        fullRemoteUrl: localUrl, // 测试模式下使用本地URL
        name: uniqueFileName,
        originalName: fileName,
        size: fileSize,
        type: fileType,
        metadata,
        testMode: true,
        localFilePath: targetFilePath,
        error: uploadError.message
      });
    }
  } catch (error) {
    console.error('=== 处理上传请求失败 ===');
    console.error('错误:', error.message);
    
    // 清理临时文件
    if (file && file.path) {
      try {
        if (fs.existsSync(file.path)) {
          fs.unlinkSync(file.path);
        }
      } catch (unlinkError) {
        console.error('清理临时文件失败:', unlinkError);
      }
    }
    
    res.json({
      success: false,
      error: error.message || '上传失败',
    });
  }
}

// 获取图片列表
app.get('/images', (req, res) => {
  console.log('=== 收到图片列表请求 ===');
  
  // 获取查询参数
  const { search, tags, model, sortBy = 'ctime', sortOrder = 'desc', limit, offset } = req.query;
  
  fs.readdir(SERVER_CONFIG.LOCAL_UPLOAD_DIR, (err, files) => {
    if (err) {
      console.error('读取上传目录失败:', err);
      return res.json({ 
        success: false, 
        error: '读取图片列表失败: ' + err.message 
      });
    }
    
    // 过滤出图片文件
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
    let imageFiles = files.filter(file => {
      const ext = path.extname(file).toLowerCase();
      return imageExtensions.includes(ext);
    });
    
    // 获取图片信息和元数据
    let images = imageFiles.map(file => {
      const filePath = path.join(SERVER_CONFIG.LOCAL_UPLOAD_DIR, file);
      const stats = fs.statSync(filePath);
      
      // 获取元数据
      const metadataResult = metadataService.getMetadata(file);
      const metadata = metadataResult.success ? metadataResult.metadata : {};
      
      // 构建完整URL
      const localUrl = `http://localhost:${SERVER_CONFIG.HTTP_PORT}/images/${file}`;
      const remoteUrl = `http://${SERVER_CONFIG.HOST}:8083/images/${file}`;
      
      return {
        filename: file,
        size: stats.size,
        ctime: stats.ctime.toISOString(),
        mtime: stats.mtime.toISOString(),
        localUrl,
        remoteUrl,
        metadata
      };
    });
    
    // 应用搜索过滤
    if (search) {
      const searchLower = search.toLowerCase();
      images = images.filter(image => {
        return (
          image.filename.toLowerCase().includes(searchLower) ||
          (image.metadata.prompt && image.metadata.prompt.toLowerCase().includes(searchLower)) ||
          (image.metadata.description && image.metadata.description.toLowerCase().includes(searchLower)) ||
          (image.metadata.originalFileName && image.metadata.originalFileName.toLowerCase().includes(searchLower))
        );
      });
    }
    
    // 应用标签过滤
    if (tags) {
      const tagList = Array.isArray(tags) ? tags : [tags];
      images = images.filter(image => {
        if (!image.metadata.tags || !Array.isArray(image.metadata.tags)) return false;
        return tagList.every(tag => image.metadata.tags.includes(tag));
      });
    }
    
    // 应用模型过滤
    if (model) {
      images = images.filter(image => {
        return image.metadata.model === model;
      });
    }
    
    // 应用排序
    images.sort((a, b) => {
      const aVal = a[sortBy];
      const bVal = b[sortBy];
      
      if (aVal < bVal) return sortOrder === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
    
    // 应用分页
    let total = images.length;
    if (limit || offset) {
      const start = parseInt(offset) || 0;
      const end = limit ? start + parseInt(limit) : images.length;
      images = images.slice(start, end);
    }
    
    console.log(`返回 ${images.length} 张图片，总共 ${total} 张`);
    res.json({ 
      success: true, 
      images, 
      total, 
      count: images.length
    });
  });
});

// 删除图片
app.delete('/images/:filename', (req, res) => {
  const filename = req.params.filename;
  console.log(`=== 收到删除图片请求: ${filename} ===`);
  
  const filePath = path.join(SERVER_CONFIG.LOCAL_UPLOAD_DIR, filename);
  
  // 检查文件是否存在
  if (!fs.existsSync(filePath)) {
    return res.json({ 
      success: false, 
      error: '图片不存在' 
    });
  }
  
  try {
    // 删除文件
    fs.unlinkSync(filePath);
    
    // 删除对应的元数据
    metadataService.deleteMetadata(filename);
    
    console.log(`图片 ${filename} 及其元数据删除成功`);
    res.json({ 
      success: true, 
      message: '图片删除成功' 
    });
  } catch (err) {
    console.error('删除图片失败:', err);
    res.json({ 
      success: false, 
      error: '删除图片失败: ' + err.message 
    });
  }
});

// 批量删除图片
app.post('/images/batch-delete', (req, res) => {
  try {
    console.log('=== 收到批量删除图片请求 ===');
    
    const { filenames } = req.body;
    
    if (!filenames || !Array.isArray(filenames)) {
      return res.status(400).json({ 
        success: false, 
        error: '请提供要删除的图片文件名数组' 
      });
    }
    
    const results = [];
    
    filenames.forEach(filename => {
      try {
        const filePath = path.join(SERVER_CONFIG.LOCAL_UPLOAD_DIR, filename);
        
        if (fs.existsSync(filePath)) {
          // 删除文件
          fs.unlinkSync(filePath);
          
          // 删除对应的元数据
          metadataService.deleteMetadata(filename);
          
          results.push({ 
            filename, 
            success: true, 
            message: '删除成功' 
          });
        } else {
          results.push({ 
            filename, 
            success: false, 
            error: '文件不存在' 
          });
        }
      } catch (err) {
        results.push({ 
          filename, 
          success: false, 
          error: err.message 
        });
      }
    });
    
    const successCount = results.filter(r => r.success).length;
    console.log(`批量删除完成，成功删除 ${successCount}/${filenames.length} 张图片`);
    
    res.json({ 
      success: true, 
      results, 
      successCount, 
      totalCount: filenames.length 
    });
  } catch (err) {
    console.error('批量删除图片失败:', err);
    res.json({ 
      success: false, 
      error: '批量删除失败: ' + err.message 
    });
  }
});

// 批量下载图片（生成ZIP文件）
app.post('/images/batch-download', (req, res) => {
  try {
    console.log('=== 收到批量下载图片请求 ===');
    
    const { filenames } = req.body;
    
    if (!filenames || !Array.isArray(filenames)) {
      return res.status(400).json({ 
        success: false, 
        error: '请提供要下载的图片文件名数组' 
      });
    }
    
    // 这里可以实现ZIP压缩下载逻辑
    // 由于需要额外的依赖（如archiver），暂时返回图片URL列表
    const downloadUrls = filenames.map(filename => {
      return {
        filename,
        localUrl: `http://localhost:${SERVER_CONFIG.HTTP_PORT}/images/${filename}`,
        remoteUrl: `http://${SERVER_CONFIG.HOST}:8083/images/${filename}`
      };
    });
    
    res.json({ 
      success: true, 
      downloadUrls, 
      message: '批量下载链接生成成功' 
    });
  } catch (err) {
    console.error('批量下载图片失败:', err);
    res.json({ 
      success: false, 
      error: '批量下载失败: ' + err.message 
    });
  }
});

// 获取图片详细信息
app.get('/images/:filename/info', (req, res) => {
  const filename = req.params.filename;
  console.log(`=== 收到图片信息请求: ${filename} ===`);
  
  const filePath = path.join(SERVER_CONFIG.LOCAL_UPLOAD_DIR, filename);
  
  // 检查文件是否存在
  if (!fs.existsSync(filePath)) {
    return res.json({ 
      success: false, 
      error: '图片不存在' 
    });
  }
  
  // 获取文件信息
  const stats = fs.statSync(filePath);
  
  // 获取元数据
  const metadataResult = metadataService.getMetadata(filename);
  const metadata = metadataResult.success ? metadataResult.metadata : {};
  
  // 构建完整URL
  const localUrl = `http://localhost:${SERVER_CONFIG.HTTP_PORT}/images/${filename}`;
  const remoteUrl = `http://${SERVER_CONFIG.HOST}:8083/images/${filename}`;
  const fullLocalUrl = localUrl;
  const fullRemoteUrl = remoteUrl;
  
  res.json({ 
    success: true, 
    image: {
      filename: filename,
      size: stats.size,
      ctime: stats.ctime.toISOString(),
      mtime: stats.mtime.toISOString(),
      path: filePath,
      localUrl: fullLocalUrl,
      remoteUrl: fullRemoteUrl,
      fullLocalUrl,
      fullRemoteUrl,
      metadata
    } 
  });
});

// 更新图片元数据
app.put('/images/:filename/metadata', (req, res) => {
  const filename = req.params.filename;
  console.log(`=== 收到更新图片元数据请求: ${filename} ===`);
  
  const updateData = req.body;
  
  // 检查文件是否存在
  const filePath = path.join(SERVER_CONFIG.LOCAL_UPLOAD_DIR, filename);
  if (!fs.existsSync(filePath)) {
    return res.json({ 
      success: false, 
      error: '图片不存在' 
    });
  }
  
  // 更新元数据
  const result = metadataService.updateMetadata(filename, updateData);
  
  if (result.success) {
    console.log(`图片 ${filename} 元数据更新成功`);
    res.json({ 
      success: true, 
      message: '元数据更新成功',
      metadata: result.metadata 
    });
  } else {
    console.error(`图片 ${filename} 元数据更新失败:`, result.error);
    res.json({ 
      success: false, 
      error: '元数据更新失败: ' + result.error 
    });
  }
});

// 批量更新图片元数据
app.put('/images/batch-metadata', (req, res) => {
  try {
    console.log('=== 收到批量更新图片元数据请求 ===');
    
    const { updates } = req.body;
    
    if (!updates || !Array.isArray(updates)) {
      return res.status(400).json({ 
        success: false, 
        error: '请提供要更新的元数据数组' 
      });
    }
    
    const results = [];
    
    updates.forEach(update => {
      const { filename, metadata } = update;
      if (!filename || !metadata) {
        results.push({ 
          filename: filename || 'unknown', 
          success: false, 
          error: '缺少文件名或元数据' 
        });
        return;
      }
      
      try {
        // 检查文件是否存在
        const filePath = path.join(SERVER_CONFIG.LOCAL_UPLOAD_DIR, filename);
        if (!fs.existsSync(filePath)) {
          results.push({ 
            filename, 
            success: false, 
            error: '图片不存在' 
          });
          return;
        }
        
        // 更新元数据
        const result = metadataService.updateMetadata(filename, metadata);
        results.push(result.success ? 
          { filename, success: true, message: '元数据更新成功' } :
          { filename, success: false, error: result.error }
        );
      } catch (err) {
        results.push({ 
          filename, 
          success: false, 
          error: err.message 
        });
      }
    });
    
    const successCount = results.filter(r => r.success).length;
    console.log(`批量更新完成，成功更新 ${successCount}/${updates.length} 张图片的元数据`);
    
    res.json({ 
      success: true, 
      results, 
      successCount, 
      totalCount: updates.length 
    });
  } catch (err) {
    console.error('批量更新图片元数据失败:', err);
    res.json({ 
      success: false, 
      error: '批量更新失败: ' + err.message 
    });
  }
});

// 启动服务器，监听所有网络接口
const server = app.listen(SERVER_CONFIG.HTTP_PORT, '0.0.0.0', () => {
  console.log('========================================');
  console.log('  图片上传服务');
  console.log('========================================');
  console.log(`  服务器地址: http://0.0.0.0:${SERVER_CONFIG.HTTP_PORT}`);
  console.log(`  上传接口: http://localhost:${SERVER_CONFIG.HTTP_PORT}/upload`);
  console.log(`  UI界面: http://localhost:${SERVER_CONFIG.HTTP_PORT}`);
  console.log('');
  console.log('  云服务器配置:');
  console.log(`  主机: ${SERVER_CONFIG.HOST}`);
  console.log(`  用户名: ${SERVER_CONFIG.USERNAME}`);
  console.log(`  远程路径: ${SERVER_CONFIG.REMOTE_PATH}`);
  console.log('');
  console.log(`  公网URL格式: http://${SERVER_CONFIG.HOST}/images/文件名.jpg`);
  console.log('========================================');
  console.log('服务已启动，等待上传请求...');
  console.log('========================================');
});

// 服务器错误处理
server.on('error', (error) => {
  console.error('=== 服务器启动失败 ===');
  console.error('错误:', error);
  
  if (error.code === 'EADDRINUSE') {
    console.error('端口已被占用，请更换端口或关闭占用该端口的服务');
  } else if (error.code === 'EACCES') {
    console.error('权限不足，请使用管理员权限运行服务');
  }
  
  process.exit(1);
});

// 优雅关闭
process.on('SIGINT', () => {
  console.log('=== 收到终止信号，正在关闭服务 ===');
  server.close(() => {
    console.log('=== 服务已关闭 ===');
    process.exit(0);
  });
});
